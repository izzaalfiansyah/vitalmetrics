<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;

use Illuminate\Database\Eloquent\Casts\Attribute;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasFactory, Notifiable, HasApiTokens;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'username',
        'nama',
        'email',
        'password',
        'tanggal_lahir',
        'jenis_kelamin',
        'role',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $appends = [
        'umur',
        'umur_bulan',
    ];

    protected function umur(): Attribute
    {
        return new Attribute(
            get: function () {
                $dateNow = new \DateTime();
                $dateBirth = new \DateTime($this->tanggal_lahir);

                $age = $dateBirth->diff($dateNow)->y;

                return $age;
            }
        );
    }
    protected function umurBulan(): Attribute
    {
        return new Attribute(
            get: function () {
                $dateNow = new \DateTime();
                $dateBirth = new \DateTime($this->tanggal_lahir);

                $month = $dateBirth->diff($dateNow)->m;

                return $month;
            }
        );
    }

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
        ];
    }
}
